package com.fitfuel;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.squareup.picasso.Picasso;

public class workout_individual extends AppCompatActivity {

    // Here all libraries/ imports are declared as below variables. All are used in the main body of the code
    private ImageView backIcon;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
//      Connect To Database
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        userId = user.getUid();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.individual_workout_activity);

        // Setting all views as a variable
        ImageView workoutVideoView = findViewById(R.id.workout_video);
        TextView workoutTitleView = findViewById(R.id.workout_title);
        TextView workoutModelView = findViewById(R.id.workout_model);
        TextView workoutTargetView = findViewById(R.id.workout_target);
        TextView workoutDifficultyView = findViewById(R.id.workout_difficulty);
        TextView workoutCaloriesView = findViewById(R.id.calories_total);
        TextView workoutRatingView = findViewById(R.id.workout_rating);
        TextView workoutAreaView = findViewById(R.id.target_area);
        backIcon = findViewById(R.id.back_button);

        // Using the previously declared image. The user will be directed back to the workout page
        backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(workout_individual.this, workout.class));
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                finish();
            }
        });

        // Creating the new intent, this takes previously passed on data form the workout class basing on the card clicked
        Intent intent = getIntent();
        String workoutId = intent.getStringExtra("workoutId");
        String workoutTitle = intent.getStringExtra("workoutTitle");
        String workoutModel = intent.getStringExtra("workoutModel");
        String workoutType = intent.getStringExtra("workoutType");
        String workoutDifficulty = intent.getStringExtra("workoutDifficulty");
        String workoutCalories = intent.getStringExtra("workoutCalories");
        String workoutRating = intent.getStringExtra("workoutRating");
        String workoutTargetArea = intent.getStringExtra("workoutTargetArea");
        String imageURL = intent.getStringExtra("workoutImageURL");

        // Populate page elements with the retrieved data
        workoutTitleView.setText(workoutTitle);
        workoutModelView.setText("By " + workoutModel);
        workoutTargetView.setText(workoutType);
        workoutDifficultyView.setText(workoutDifficulty);
        workoutCaloriesView.setText(workoutCalories);
        workoutRatingView.setText(workoutRating + "/5");
        workoutAreaView.setText(workoutTargetArea);

        //Picasso inserts the image from the retrieved data
        Picasso.get().load(imageURL).into(workoutVideoView);

    }
}