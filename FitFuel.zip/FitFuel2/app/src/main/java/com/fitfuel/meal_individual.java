package com.fitfuel;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.squareup.picasso.Picasso;

public class meal_individual extends AppCompatActivity {

    // Here all libraries/ imports are declared as below variables. All are used in the main body of the code
    private ImageView backIcon;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
//      Connect To Database
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        userId = user.getUid();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.individual_meal_activity);

        // Setting all views as a variable
        ImageView mealImageView = findViewById(R.id.meal_image);
        TextView mealTitleView = findViewById(R.id.meal_title);
        TextView mealAuthorView = findViewById(R.id.meal_author);
        TextView mealTimeView = findViewById(R.id.prep_time);
        TextView mealCaloriesView = findViewById(R.id.calories_total);
        TextView mealRatingView = findViewById(R.id.meal_rating);
        TextView mealDescriptionView = findViewById(R.id.meal_description);
        TextView mealIngredientsView = findViewById(R.id.meal_ingredients);
        TextView mealInstructionsView = findViewById(R.id.meal_instructions);
        backIcon = findViewById(R.id.back_button);

        // Using the previously declared image. The user will be directed back to the meal page
        backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(meal_individual.this, meal.class));
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                finish();
            }
        });

        // Creating the new intent, this takes previously passed on data form the meal class basing on the card clicked
        Intent intent = getIntent();
        String mealId = intent.getStringExtra("mealId");
        String mealTitle = intent.getStringExtra("mealTitle");
        String mealAuthor = intent.getStringExtra("mealAuthor");
        String mealType = intent.getStringExtra("mealType");
        String mealTime = intent.getStringExtra("mealTime");
        String mealCalories = intent.getStringExtra("mealCalories");
        String mealRating = intent.getStringExtra("mealRating");
        String mealDescription = intent.getStringExtra("mealDescription");
        String mealIngredients = intent.getStringExtra("mealIngredients");
        String mealInstructions = intent.getStringExtra("mealInstructions");
        String mealImage = intent.getStringExtra("mealImage");

        // Populate UI elements with the retrieved data
        mealTitleView.setText(mealTitle);
        mealAuthorView.setText("By " + mealAuthor);
        mealTimeView.setText(mealTime + " mins");
        mealCaloriesView.setText(mealCalories + " kcal");
        mealRatingView.setText(mealRating + "/5");
        mealDescriptionView.setText(mealDescription);
        mealIngredientsView.setText(mealIngredients);
        mealInstructionsView.setText(mealInstructions);

        //Picasso inserts the image from the retrieved data
        Picasso.get().load(mealImage).into(mealImageView);

    }
}