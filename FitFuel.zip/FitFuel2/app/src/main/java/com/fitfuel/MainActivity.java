package com.fitfuel;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {

    // Here all libraries/ imports are declared as below variables. All are used in the main body of the code
    SharedPreferences prefs = null; // Setting preferences to null, this will enable the application to check for first time users
    String userId;
    TextView name;
    ImageView profileImage;
    FirebaseAuth auth;
    FirebaseFirestore fstore;
    CardView workoutCard, mealCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        prefs = getSharedPreferences("com.mycompany.myAppName", MODE_PRIVATE); // This sets shared preferences to what is locally saved for further condition
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser(); //Sets the user to the current user
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Assign values to variables
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        // Initializing the firebase authentication & firestore, ensuring the database is connected
        fstore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        // Declaring the views fields in the layout
        workoutCard = findViewById(R.id.workout_card);
        mealCard = findViewById(R.id.meal_card);
        name = findViewById(R.id.name_field); // Target the TextView within the layout to display the value.
        profileImage = findViewById(R.id.profile_icon); // Target the ImageView in the layout

        //active item
        bottomNavigationView.setSelectedItemId(R.id.home);

        // By running the prefs variable through a conditional statement, the application
        // can check if it is the user's first time running the application:
        // First Run = Show landing page
        // Not First Run = continue to the else statement which checks if the user is signed in:
        // If user is signed in then continue, if not the direct to logon page
        if (prefs.getBoolean("firstrun", true)) {
            startActivity(new Intent(MainActivity.this, landing_page_one.class));
            prefs.edit().putBoolean("firstrun", false).apply();
            finish();
        } else {
            if (user != null) {
                userId = auth.getCurrentUser().getUid(); // declare userID from current user ID
                // User is not null, then continue
            } else {
                startActivity(new Intent(MainActivity.this, landing_page_logon.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
            }
        }

        // This references the collection "users" in the firestore database
        DocumentReference documentReference = fstore.collection("users").document(userId);

        // Using snapshot listener, the document can be read
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Log.e("account", "Error getting document: " + error); // If no collection, return error
                    return;
                }
                // If collection exists, use the stored value of user_name and set it as the previously declared TextView
                if (documentSnapshot != null && documentSnapshot.exists()) {
                    String userName = documentSnapshot.getString("user_name");
                    String profileImageURL = documentSnapshot.getString("profile_image");
                    if (userName != null) {
                        name.setText(userName);
                    }
                    if (profileImageURL != null && !profileImageURL.isEmpty()) {
                        // Using Glide library to load image
                        Glide.with(MainActivity.this)
                                .load(profileImageURL)
                                .into(profileImage);
                    }
                } else {
                    Log.d("account", "No such document");
                }
            }
        });

        // This creates an function allowing the application to listen for the user interacting with icons
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            // Function to make the bottom navigation bar intractable
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                // Set conditions to each navigation item from the "bottom_menu" layout
                //If an item is clicked, it will slide out into the next page
                if (item.getItemId() == R.id.home) {
                    //Do not do anything as this is the current page
                } else if (item.getItemId() == R.id.workout) {
                    startActivity(new Intent(MainActivity.this, workout.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else if (item.getItemId() == R.id.meal) {
                    startActivity(new Intent(MainActivity.this, meal.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else if (item.getItemId() == R.id.settings) {
                    startActivity(new Intent(MainActivity.this, settings.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                }
                return false;
            }
        });

        // Using the previously declared cardView. The user will be directed to their profile
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, settings.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
            }
        });

        // Using the previously declared cardView. The user will be directed to the workout page
        workoutCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                Intent intent = new Intent(MainActivity.this, workout.class);
                startActivity(intent);

                finish();
            }
        });

        // Using the previously declared cardView. The user will be directed to the meal page
        mealCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                Intent intent = new Intent(MainActivity.this, meal.class);
                startActivity(intent);

                finish();
            }
        });

    }

}