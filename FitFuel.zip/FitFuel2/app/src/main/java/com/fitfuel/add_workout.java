package com.fitfuel;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;

import com.bumptech.glide.Glide;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class add_workout extends AppCompatActivity {

    // Here all libraries/ imports are declared as below variables. All are used in the main body of the code
    private ImageView backIcon;
    private EditText title, calories;
    public Uri imageUri;
    private String userId;
    private Spinner workoutType, workoutDifficulty, workoutTargetArea;
    private Button workoutImage, submit;
    private String documentId, imageUrl;
    private FirebaseStorage storage;
    private FirebaseFirestore fstore;
    private StorageReference storageReference;
    private FirebaseAuth auth;
    private String userName;  // Add this variable to store the user name

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_workout); // Assuming your layout file is named activity_workout.xml

        // Initialize Firebase & More
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();
        auth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();
        userId = auth.getCurrentUser().getUid();

        // Setting all views as a variable
        backIcon = findViewById(R.id.back_button);
        title = findViewById(R.id.title);
        calories = findViewById(R.id.calories);
        workoutType = findViewById(R.id.type);
        workoutDifficulty = findViewById(R.id.difficulty);
        workoutTargetArea = findViewById(R.id.target_area);
        workoutImage = findViewById(R.id.workout_image);
        submit = findViewById(R.id.submit);

        // Define arrays of items for each Spinner
        String[] itemsType = {"", "Strength Training", "Cardio", "Weight Loss", "Muscle Growth"};
        String[] itemsDifficulty = {"", "Beginner", "Intermediate", "Advanced", "Expert"};
        String[] itemsTargetArea = {"", "upper", "lower"};

        // Create ArrayAdapter for each Spinner using the respective array of items and a default spinner layout
        ArrayAdapter<String> adapterType = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, itemsType);
        ArrayAdapter<String> adapterDifficulty = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, itemsDifficulty);
        ArrayAdapter<String> adapterArea = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, itemsTargetArea);

        // Specify the layout to use when the list of choices appears for each Spinner
        adapterType.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapterDifficulty.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapterArea.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Apply the adapters to the Spinners
        workoutType.setAdapter(adapterType);
        workoutDifficulty.setAdapter(adapterDifficulty);
        workoutTargetArea.setAdapter(adapterArea);

        workoutImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        // Using the previously declared image. The user will be directed back to the workout page
        backIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(add_workout.this, workout.class));
                overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
                finish();
            }
        });
        // Using the previously declared image. The upload function starts
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                upload();
            }
        });

        // Fetch the user name from Firestore and set the userName variable
        fetchUserName();
    }

    private void fetchUserName() {
        DocumentReference userInfo = fstore.collection("users").document(userId);

        // Using snapshot listener, the document can be read
        userInfo.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Log.e("account", "Error getting document: " + error); // If no collection, return error
                    return;
                }
                // If collection exists, use the stored value of user_name
                if (documentSnapshot != null && documentSnapshot.exists()) {
                    userName = documentSnapshot.getString("user_name");
                } else {
                    Log.d("account", "No such document");
                }
            }
        });
    }

    // Using android features, the user will access their gallery
    private void openGallery() {
        Intent accessGallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(accessGallery, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            // Get the selected image link
            imageUri = data.getData();
        }
    }

    // Method to generate a unique report ID
    private String generatedocumentId() {
        return UUID.randomUUID().toString();
    }

    // Method to upload report
    private void upload() {
        // Generate report ID
        documentId = generatedocumentId();

        // Get selected image URL
        if (imageUri != null && workoutType.getSelectedItemPosition() > 0 && workoutDifficulty.getSelectedItemPosition() > 0 && workoutTargetArea.getSelectedItemPosition() > 0 && !calories.getText().toString().isEmpty() && !title.getText().toString().isEmpty()) {
            StorageReference imageRef = storageReference.child("workout_images").child(documentId + ".jpg");

            // Upload image to Firebase Storage
            imageRef.putFile(imageUri)
                    .addOnSuccessListener(taskSnapshot -> {
                        // Image uploaded successfully
                        // Get the download URL of the image
                        imageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                            // Save the image URL
                            imageUrl = uri.toString();

                            // Upload the report data to Firebase Database
                            uploadData();
                        });
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(add_workout.this, "Failed to Upload Image", Toast.LENGTH_SHORT).show();
                    });
        } else {
            // No image selected
            Toast.makeText(add_workout.this, "Form Incomplete!", Toast.LENGTH_SHORT).show();
        }
    }

    private void uploadData() {
        // Create a new document in the "reports" collection with the generated report ID
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference reportRef = db.collection("workout").document(documentId);

        String caloriesZero = (calories.getText().toString());

        // Create a Map to hold the report data
        Map<String, Object> documentData = new HashMap<>();
        documentData.put("title", title.getText().toString());
        documentData.put("model", userName);  // Include the userName in the document data
        documentData.put("type", workoutType.getSelectedItem().toString());
        documentData.put("difficulty", workoutDifficulty.getSelectedItem().toString());
        documentData.put("calories", caloriesZero);
        documentData.put("rating", 0);
        documentData.put("placement", workoutTargetArea.getSelectedItem().toString());
        documentData.put("target-area", workoutTargetArea.getSelectedItem().toString());
        documentData.put("image", imageUrl);

        // Add the report data to the Firestore document
        reportRef.set(documentData)
                .addOnSuccessListener(aVoid -> {
                    // Report data uploaded successfully
                    Toast.makeText(add_workout.this, "Workout Added Successfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(add_workout.this, workout.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(add_workout.this, "Failed to Upload Report", Toast.LENGTH_SHORT).show();
                });
    }

}
