package com.fitfuel;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class sign_up extends AppCompatActivity {

    // Here all libraries/ imports are declared as below variables. All are used in the main body of the code
    private FirebaseAuth auth;
    private EditText nameEditText, emailEditText, passwordEditText;
    private Button sign_up;
    FirebaseFirestore fstore;
    String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up_activity);

        // Initializing the firebase authentication & firebase firestore instances, ensuring the database is connected
        auth = FirebaseAuth.getInstance();
        fstore = FirebaseFirestore.getInstance();

        // Declaring the edit text, button fields in the layout
        nameEditText = findViewById(R.id.name_field);
        emailEditText = findViewById(R.id.email_field);
        passwordEditText = findViewById(R.id.password_field);
        sign_up = findViewById(R.id.sign_up);

        // Via the previously declared button, this function functions.
        sign_up.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               // Using the previously set variables, the text is fetched and converted into a string as that is the data type required..
               String name = nameEditText.getText().toString().trim();
               String email = emailEditText.getText().toString().trim();
               String pass = passwordEditText.getText().toString().trim();

               // the below statements check the validity of the data inputted, this not only decreases the probability of an error but also increases security
               if (email.isEmpty()){
                   emailEditText.setError("Email cannot be empty!");
               }
               if (pass.isEmpty()){
                   passwordEditText.setError("Password cannot be empty!");
               }
               if (pass.length() < 6) {
                   passwordEditText.setError("Password must be longer than 6 characters!");
               }
               if (pass.isEmpty()){
                   passwordEditText.setError("Password cannot be empty!");
               }else {
                   // Once the user enters a correct password, the authentication function within the firebase auth library.
                   // Passing on the email and password variables inputted onto the onComplete function
                   auth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                       @Override
                       public void onComplete(@NonNull Task<AuthResult> task) {
                           if (task.isSuccessful()){
                               // Notifying the user that the registration process has been successful
                               Toast.makeText(sign_up.this, "Sign Up Successful", Toast.LENGTH_SHORT).show();

                               // Fetching the current user ID for user info storage purposes
                               userID = auth.getCurrentUser().getUid();
                               // The document reference is set to create a new user in the users collection under the userID set previously
                               DocumentReference documentReference = fstore.collection("users").document(userID);

                               // Inserting two fields as below into the document
                               Map<String,Object> user = new HashMap<>();
                               user.put("user_name", name);
                               user.put("user_email", email);

                               // Welcome message confirming sign up
                               documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                   @Override
                                   public void onSuccess(Void unused) {
                                       Toast.makeText(sign_up.this, "Welcome " + name , Toast.LENGTH_SHORT).show();
                                   }
                               });

                               // Directing the user to the sign in page to ensure logon was correct.
                               startActivity(new Intent(sign_up.this, sign_in.class));
                           } else {
                               // Message stating an error to the user.
                               Toast.makeText(sign_up.this, "Sign Up Failed!" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                           }
                       }
                   });
               }

           }
        });

        // Layout sign in button declared, once pressed, the user is directed to the sign in page
        Button signInButton = findViewById(R.id.sign_in);
        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(sign_up.this, sign_in.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
            }
        });


    }

}