package com.fitfuel;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class sign_in extends AppCompatActivity {

    // Here all libraries/ imports are declared as below variables. All are used in the main body of the code
    private FirebaseAuth auth;
    private EditText loginEmail, loginPassword;
    private Button loginButton;
    private TextView change_password_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_in_activity);

        // Initializing the firebase authentication, ensuring the database is connected
        auth = FirebaseAuth.getInstance();

        // Declaring the edit text, button fields in the layout
        loginEmail = findViewById(R.id.email_field);
        loginPassword = findViewById(R.id.password_field);
        loginButton = findViewById(R.id.sign_in);
        change_password_text = findViewById(R.id.forgot_password);

        // Via the previously declared button, this function functions.
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Using the previously set variables, the text is fetched and converted into a string as that is the data type required..
                String email = loginEmail.getText().toString();
                String pass = loginPassword.getText().toString();

                // A statement used to check the validity of information entered, checking if the information matches authentication data
                if (!email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    if(!pass.isEmpty()) {
                        auth.signInWithEmailAndPassword(email, pass)
                                .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                                    @Override
                                    public void onSuccess(AuthResult authResult) {
                                        Toast.makeText(sign_in.this, "Login Successful", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(sign_in.this, MainActivity.class));
                                        finish();
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(sign_in.this, "Login Unsuccessful", Toast.LENGTH_SHORT).show();
                                    }
                                });
                // Messages stating an error to the user.
                    } else {
                        loginPassword.setError("Password cannot be empty!");
                    }
                } else if(email.isEmpty()) {
                    loginEmail.setError("Email cannot be empty!");
                } else {
                    loginEmail.setError("Please enter a valid email!");
                }

            }
        });

        // Layout sign up button declared, once pressed, the user is directed to the sign up page
        Button signUpButton = findViewById(R.id.sign_up);
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(sign_in.this, sign_up.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
            }
        });

        // This function enables a user to reset their password using firebase reset fucntion
        change_password_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Setting an editText variable as resetMail
                EditText resetMail = new EditText(v.getContext());
                // Analog popup indicating the user with further instructions and the ability to enter their email
                AlertDialog.Builder passwordResetDialog = new AlertDialog.Builder(v.getContext());
                passwordResetDialog.setTitle("Reset Password?");
                passwordResetDialog.setMessage("Enter your email address to receive a reset link.");
                passwordResetDialog.setView(resetMail);

                // Once the user sends off the report, they will receive an email from Firebase with a link to reset their password
                passwordResetDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String mail = resetMail.getText().toString();
                        auth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(sign_in.this, "Reset link sent to email!", Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(sign_in.this, "Error! Reset Link Not Sent!" + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });

                    }
                });

                passwordResetDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });

                // Creates the dialog popup
                passwordResetDialog.create().show();

            }
        });

    }

}
