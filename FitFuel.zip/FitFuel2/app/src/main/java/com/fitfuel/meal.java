package com.fitfuel;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

public class meal extends AppCompatActivity {

    // Here all libraries/ imports are declared as below variables. All are used in the main body of the code
    String userId; // To fetch current user's information
    TextView name; // target user name
    ImageView profileImage, addButton; // declare image view
    FirebaseAuth auth; //declaring authenticator service
    FirebaseFirestore fstore; // declaring firestore service
    LinearLayout chickenLayout, beefLayout; // Declaring this will ensure that all ads are added into a linear layout
    private BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser(); //Sets the user to the current user
        super.onCreate(savedInstanceState);
        setContentView(R.layout.meal_activity);

        // Assign values to variables
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Declaring the views fields in the layout
        name = findViewById(R.id.name_field); // Target the TextView within the layout to display the value.
        profileImage = findViewById(R.id.profile_icon); // Target the ImageView in the layout
        addButton = findViewById(R.id.add_icon); //Icon to add a new item
        
        // Initializing the firebase authentication & firestore, ensuring the database is connected
        fstore = FirebaseFirestore.getInstance(); // Initializes firestore instance
        auth = FirebaseAuth.getInstance(); // Initializes authentication instance
        userId = auth.getCurrentUser().getUid(); // declare userID from current user ID
        
        // Initialize adsLayout
        chickenLayout = findViewById(R.id.chicken_meals);
        beefLayout = findViewById(R.id.beef_meals);

        //active fragment
        bottomNavigationView.setSelectedItemId(R.id.meal);

        // Fetch all meals from firestore using a function
        fetchAndPopulateChickenMeal();
        fetchAndPopulateBeefMeal();

        // This references the collection "users" in the firestore database as the userId
        DocumentReference documentReference = fstore.collection("users").document(userId);

        // Using snapshot listener, the document can be read
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Log.e("account", "Error getting document: " + error); // If no collection, return error
                    return;
                }
                // If collection exists, use the stored value of user_name and set it as the previously declared TextView
                if (documentSnapshot != null && documentSnapshot.exists()) {
                    String userName = documentSnapshot.getString("user_name");
                    String profileImageURL = documentSnapshot.getString("profile_image");
                    String userRole = documentSnapshot.getString("user_role"); // This has been set as only a model can add a meal, the button will only be visible if the user has the role
                    if (userName != null) {
                        name.setText(userName);
                    }
                    if (profileImageURL != null && !profileImageURL.isEmpty()) {
                        // Using Glide library to load image
                        Glide.with(meal.this)
                                .load(profileImageURL)
                                .into(profileImage);
                    }
                    if ("model".equals(userRole)) {
                        // Only make the addition image visible IF the user has the adequate role
                        addButton.setVisibility(View.VISIBLE);
                    }
                } else {
                    Log.d("account", "No such document");
                }
            }
        });

        // Using the previously declared cardView. The user will be directed to the add meal meal
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(meal.this, add_meal.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
            }
        });

        // Using the previously declared cardView. The user will be directed to their profile
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(meal.this, settings.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
            }
        });

        // This creates an function allowing the application to listen for the user interacting with icons
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            // Function to make the bottom navigation bar intractable
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                // Set conditions to each navigation item from the "bottom_menu" layout
                //If an item is clicked, it will slide out into the next page
                if (item.getItemId() == R.id.home) {
                    startActivity(new Intent(meal.this, MainActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else if (item.getItemId() == R.id.workout) {
                    startActivity(new Intent(meal.this, workout.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else if (item.getItemId() == R.id.meal) {
                    // Current
                } else if (item.getItemId() == R.id.settings) {
                    startActivity(new Intent(meal.this, settings.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                }
                return false;
            }
        });

    }

    // Function which fetches and populates all meals that are classed as upper, displaying them within the upper linear layout
    private void fetchAndPopulateChickenMeal() {
        fstore.collection("meals").whereEqualTo("type", "chicken").get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                            // Fetch all data from the Firestore document
                            String mealId = documentSnapshot.getId();
                            String mealTitle = documentSnapshot.getString("title");
                            String mealAuthor = documentSnapshot.getString("author");
                            String mealType = documentSnapshot.getString("type");
                            String mealTime = documentSnapshot.getString("time");
                            String mealCalories = documentSnapshot.getString("calories");
                            Double mealRating = documentSnapshot.getDouble("rating");
                            Double mealNumericalRating = documentSnapshot.getDouble("rating");
                            String mealDescription = documentSnapshot.getString("description");
                            String mealIngredients = documentSnapshot.getString("ingredients");
                            String mealInstructions = documentSnapshot.getString("instructions");
                            String mealImage = documentSnapshot.getString("image");

                            View cardView = getLayoutInflater().inflate(R.layout.show_all_meals, null);

                            // Get references to TextViews inside the CardView
                            ImageView individualMealImage = cardView.findViewById(R.id.meal_image);
                            TextView individualMealTitle = cardView.findViewById(R.id.name_of_meal);
                            TextView individualMealModel = cardView.findViewById(R.id.name_of_author);
                            TextView individualMealNumericalRating = cardView.findViewById(R.id.numerical_rating);
                            RatingBar individualMealRating = cardView.findViewById(R.id.meal_rating);

                            String mealNumericalRatingString = String.valueOf(mealNumericalRating);

                            // Set pet information to TextViews
                            individualMealTitle.setText(mealTitle);
                            individualMealModel.setText("By " + mealAuthor);

                            // Input the image using Picasso into the ImageView
                            if (mealImage != null && !mealImage.isEmpty()) {
                                Picasso.get().load(mealImage).placeholder(R.drawable.spicy_korean_chicken)
                                        .error(R.drawable.spicy_korean_chicken).into(individualMealImage);
                            }

                            // Set the rating value on the RatingBar
                            if (mealRating != null) {
                                individualMealRating.setRating(mealRating.floatValue());
                                individualMealNumericalRating.setText(mealNumericalRatingString);
                            } else {
                                individualMealRating.setRating(0);
                                individualMealNumericalRating.setText("0");
                            }

                            // Add onClickListener to each CardView
                            cardView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent(meal.this, meal_individual.class);
                                    // Pass relevant details to the new activity
                                    intent.putExtra("mealId", mealId);
                                    intent.putExtra("mealTitle", mealTitle);
                                    intent.putExtra("mealAuthor", mealAuthor);
                                    intent.putExtra("mealType", mealType);
                                    intent.putExtra("mealTime", mealTime);
                                    intent.putExtra("mealCalories", mealCalories);
                                    intent.putExtra("mealRating", mealRating);
                                    intent.putExtra("mealDescription", mealDescription);
                                    intent.putExtra("mealIngredients", mealIngredients);
                                    intent.putExtra("mealInstructions", mealInstructions);
                                    intent.putExtra("mealImage", mealImage);
                                    startActivity(intent);
                                }
                            });

                            // Add the inflated CardView to your recommendedLayout
                            chickenLayout.addView(cardView);
                        }
                    }
                });

    }

    // Function which fetches and populates all meals that are classed as beef, displaying them within the upper linear layout
    private void fetchAndPopulateBeefMeal() {
        fstore.collection("meals").whereEqualTo("type", "beef").get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                            // Fetch all data from the Firestore document
                            String mealId = documentSnapshot.getId();
                            String mealTitle = documentSnapshot.getString("title");
                            String mealAuthor = documentSnapshot.getString("author");
                            String mealType = documentSnapshot.getString("type");
                            String mealTime = documentSnapshot.getString("time");
                            String mealCalories = documentSnapshot.getString("calories");
                            Double mealRating = documentSnapshot.getDouble("rating");
                            Double mealNumericalRating = documentSnapshot.getDouble("rating");
                            String mealDescription = documentSnapshot.getString("description");
                            String mealIngredients = documentSnapshot.getString("ingredients");
                            String mealInstructions = documentSnapshot.getString("instructions");
                            String mealImage = documentSnapshot.getString("image");

                            View cardView = getLayoutInflater().inflate(R.layout.show_all_meals, null);

                            // Get references to TextViews inside the CardView
                            ImageView individualMealImage = cardView.findViewById(R.id.meal_image);
                            TextView individualMealTitle = cardView.findViewById(R.id.name_of_meal);
                            TextView individualMealModel = cardView.findViewById(R.id.name_of_author);
                            TextView individualMealNumericalRating = cardView.findViewById(R.id.numerical_rating);
                            RatingBar individualMealRating = cardView.findViewById(R.id.meal_rating);

                            String mealNumericalRatingString = String.valueOf(mealNumericalRating);

                            // Set pet information to TextViews
                            individualMealTitle.setText(mealTitle);
                            individualMealModel.setText("By " + mealAuthor);

                            // Input the image using Picasso into the ImageView
                            if (mealImage != null && !mealImage.isEmpty()) {
                                Picasso.get().load(mealImage).placeholder(R.drawable.spicy_korean_chicken)
                                        .error(R.drawable.spicy_korean_chicken).into(individualMealImage);
                            }

                            // Set the rating value on the RatingBar
                            if (mealRating != null) {
                                individualMealRating.setRating(mealRating.floatValue());
                                individualMealNumericalRating.setText(mealNumericalRatingString);
                            } else {
                                individualMealRating.setRating(0);
                                individualMealNumericalRating.setText("0");
                            }

                            // Add onClickListener to each CardView
                            cardView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent(meal.this, meal_individual.class);
                                    // Pass relevant details to the new activity
                                    intent.putExtra("mealId", mealId);
                                    intent.putExtra("mealTitle", mealTitle);
                                    intent.putExtra("mealAuthor", mealAuthor);
                                    intent.putExtra("mealType", mealType);
                                    intent.putExtra("mealTime", mealTime);
                                    intent.putExtra("mealCalories", mealCalories);
                                    intent.putExtra("mealRating", mealRating);
                                    intent.putExtra("mealDescription", mealDescription);
                                    intent.putExtra("mealIngredients", mealIngredients);
                                    intent.putExtra("mealInstructions", mealInstructions);
                                    intent.putExtra("mealImage", mealImage);
                                    startActivity(intent);
                                }
                            });

                            // Add the inflated CardView to your recommendedLayout
                            beefLayout.addView(cardView);
                        }
                    }
                });

    }

}