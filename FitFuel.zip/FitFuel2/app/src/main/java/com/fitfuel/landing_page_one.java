package com.fitfuel;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class landing_page_one extends AppCompatActivity {

    // This class sets the layout as the landing page one
    // This class only works for first time users to provide further information about the applications purpose.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.landing_one_activity);

        // Once the continue button text view is pressed, the application will lead to the next page.
        TextView clickableText = findViewById(R.id.continue_next);
        clickableText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(landing_page_one.this, landing_page_two.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
            }

        });

    }

}
