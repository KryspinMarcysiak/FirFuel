package com.fitfuel;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.squareup.picasso.Picasso;

public class workout extends AppCompatActivity {

    // Here all libraries/ imports are declared as below variables. All are used in the main body of the code
    String userId;
    TextView name;
    ImageView profileImage, addButton;
    FirebaseAuth auth;
    FirebaseFirestore fstore;
    LinearLayout upperLayout, lowerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser(); //Sets the user to the current user
        super.onCreate(savedInstanceState);
        setContentView(R.layout.workout_activity);

        // Assign values to variables
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Declaring the views fields in the layout
        name = findViewById(R.id.name_field); // Target the TextView within the layout to display the value.
        profileImage = findViewById(R.id.profile_icon); // Target the ImageView in the layout
        addButton = findViewById(R.id.add_icon); //Icon to add a new item

        // Initializing the firebase authentication & firestore, ensuring the database is connected
        fstore = FirebaseFirestore.getInstance(); // Initializes firestore instance
        auth = FirebaseAuth.getInstance(); // Initializes authentication instance
        userId = auth.getCurrentUser().getUid(); // declare userID from current user ID

        // Initialize adsLayout
        upperLayout = findViewById(R.id.upper_workouts);
        lowerLayout = findViewById(R.id.lower_workouts);

        //active item
        bottomNavigationView.setSelectedItemId(R.id.workout);

        // Fetch all workouts from firestore using a function
        fetchAndPopulateUpperDay();
        fetchAndPopulateLowerDay();

        // This references the collection "users" in the firestore database as the userId
        DocumentReference documentReference = fstore.collection("users").document(userId);

        // Using snapshot listener, the document can be read
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Log.e("account", "Error getting document: " + error); // If no collection, return error
                    return;
                }
                // If collection exists, use the stored value of user_name and set it as the previously declared TextView
                if (documentSnapshot != null && documentSnapshot.exists()) {
                    String userName = documentSnapshot.getString("user_name");
                    String profileImageURL = documentSnapshot.getString("profile_image");
                    String userRole = documentSnapshot.getString("user_role"); // This has been set as only a model can add a workout, the button will only be visible if the user has the role
                    if (userName != null) {
                        name.setText(userName);
                    }
                    if (profileImageURL != null && !profileImageURL.isEmpty()) {
                        // Using Glide library to load image
                        Glide.with(workout.this)
                                .load(profileImageURL)
                                .into(profileImage);
                    }
                    if ("model".equals(userRole)) {
                        // Only make the addition image visible IF the user has the adequate role
                        addButton.setVisibility(View.VISIBLE);
                    }
                } else {
                    Log.d("account", "No such document");
                }
            }
        });

        // Using the previously declared cardView. The user will be directed to the add workout class
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(workout.this, add_workout.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
            }
        });

        // Using the previously declared cardView. The user will be directed to their profile
        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(workout.this, settings.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                finish();
            }
        });

        // This creates an function allowing the application to listen for the user interacting with icons
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            // Function to make the bottom navigation bar intractable
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                // Set conditions to each navigation item from the "bottom_menu" layout
                //If an item is clicked, it will slide out into the next page
                if (item.getItemId() == R.id.home) {
                    startActivity(new Intent(workout.this, MainActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else if (item.getItemId() == R.id.workout) {
                    //Do not do anything as this is the current page
                } else if (item.getItemId() == R.id.meal) {
                    startActivity(new Intent(workout.this, meal.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else if (item.getItemId() == R.id.settings) {
                    startActivity(new Intent(workout.this, settings.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                }
                return false;
            }
        });

    }

    // Function which fetches and populates all workouts that are classed as upper, displaying them within the upper linear layout
    private void fetchAndPopulateUpperDay() {
        fstore.collection("workout").whereEqualTo("placement", "upper").get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                            // Fetch all data from the Firestore document
                            String workoutId = documentSnapshot.getId();
                            String workoutTitle = documentSnapshot.getString("title");
                            String workoutModel = documentSnapshot.getString("model");
                            String workoutType = documentSnapshot.getString("type");
                            String workoutDifficulty = documentSnapshot.getString("difficulty");
                            String workoutCalories = documentSnapshot.getString("calories");
                            Double workoutRating = documentSnapshot.getDouble("rating");
                            Double workoutNumericalRating = documentSnapshot.getDouble("rating");
                            String workoutTargetArea = documentSnapshot.getString("target-area");
                            String workoutImageURL = documentSnapshot.getString("image");

                            View cardView = getLayoutInflater().inflate(R.layout.show_all_workouts, null);

                            // Get references to TextViews inside the CardView
                            ImageView individualWorkoutImage = cardView.findViewById(R.id.workout_image);
                            TextView individualWorkoutTitle = cardView.findViewById(R.id.name_of_workout);
                            TextView individualWorkoutModel = cardView.findViewById(R.id.name_of_author);
                            TextView individualWorkoutNumericalRating = cardView.findViewById(R.id.numerical_rating);
                            RatingBar individualWorkoutRating = cardView.findViewById(R.id.workout_rating);

                            String workoutNumericalRatingString = String.valueOf(workoutNumericalRating);

                            // Set pet information to TextViews
                            individualWorkoutTitle.setText(workoutTitle);
                            individualWorkoutModel.setText("By " + workoutModel);

                            // Input the image using Picasso into the ImageView
                            if (workoutImageURL != null && !workoutImageURL.isEmpty()) {
                                Picasso.get().load(workoutImageURL).placeholder(R.drawable.page1full)
                                        .error(R.drawable.page1full).into(individualWorkoutImage);
                            }

                            // Set the rating value on the RatingBar
                            if (workoutRating != null) {
                                individualWorkoutRating.setRating(workoutRating.floatValue());
                                individualWorkoutNumericalRating.setText(workoutNumericalRatingString);
                            } else {
                                individualWorkoutRating.setRating(0);
                                individualWorkoutNumericalRating.setText("0");
                            }

                            // Add onClickListener to each CardView
                            cardView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent(workout.this, workout_individual.class);
                                    // Pass relevant details to the new activity
                                    intent.putExtra("workoutId", workoutId);
                                    intent.putExtra("workoutTitle", workoutTitle);
                                    intent.putExtra("workoutModel", workoutModel);
                                    intent.putExtra("workoutType", workoutType);
                                    intent.putExtra("workoutDifficulty", workoutDifficulty);
                                    intent.putExtra("workoutCalories", workoutCalories);
                                    intent.putExtra("workoutRating", workoutRating);
                                    intent.putExtra("workoutTargetArea", workoutTargetArea);
                                    intent.putExtra("workoutImageURL", workoutImageURL);
                                    startActivity(intent);
                                }
                            });
                            // The upper Layout is generated
                            upperLayout.addView(cardView);
                        }
                    }
                });

    }

    // Function which fetches and populates all workouts that are classed as upper, displaying them within the upper linear layout
    private void fetchAndPopulateLowerDay() {
        fstore.collection("workout").whereEqualTo("placement", "lower").get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                            // Fetch all data from the Firestore document
                            String workoutId = documentSnapshot.getId();
                            String workoutTitle = documentSnapshot.getString("title");
                            String workoutModel = documentSnapshot.getString("model");
                            String workoutType = documentSnapshot.getString("type");
                            String workoutDifficulty = documentSnapshot.getString("difficulty");
                            String workoutCalories = documentSnapshot.getString("calories");
                            Double workoutRating = documentSnapshot.getDouble("rating");
                            Double workoutNumericalRating = documentSnapshot.getDouble("rating");
                            String workoutTargetArea = documentSnapshot.getString("target-area");
                            String workoutImageURL = documentSnapshot.getString("image");

                            View cardView = getLayoutInflater().inflate(R.layout.show_all_workouts, null);

                            // Get references to TextViews inside the CardView
                            ImageView individualWorkoutImage = cardView.findViewById(R.id.workout_image);
                            TextView individualWorkoutTitle = cardView.findViewById(R.id.name_of_workout);
                            TextView individualWorkoutModel = cardView.findViewById(R.id.name_of_author);
                            TextView individualWorkoutNumericalRating = cardView.findViewById(R.id.numerical_rating);
                            RatingBar individualWorkoutRating = cardView.findViewById(R.id.workout_rating);

                            String workoutNumericalRatingString = String.valueOf(workoutNumericalRating);

                            // Set pet information to TextViews
                            individualWorkoutTitle.setText(workoutTitle);
                            individualWorkoutModel.setText("By " + workoutModel);

                            // Input the image using Picasso into the ImageView
                            if (workoutImageURL != null && !workoutImageURL.isEmpty()) {
                                Picasso.get().load(workoutImageURL).placeholder(R.drawable.page1full)
                                        .error(R.drawable.page1full).into(individualWorkoutImage);
                            }

                            // Set the rating value on the RatingBar
                            if (workoutRating != null) {
                                individualWorkoutRating.setRating(workoutRating.floatValue());
                                individualWorkoutNumericalRating.setText(workoutNumericalRatingString);
                            } else {
                                individualWorkoutRating.setRating(0);
                                individualWorkoutNumericalRating.setText("0");
                            }

                            // Add onClickListener to each CardView
                            cardView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    Intent intent = new Intent(workout.this, workout_individual.class);
                                    // Pass relevant details to the new activity
                                    intent.putExtra("workoutId", workoutId);
                                    intent.putExtra("workoutTitle", workoutTitle);
                                    intent.putExtra("workoutModel", workoutModel);
                                    intent.putExtra("workoutType", workoutType);
                                    intent.putExtra("workoutDifficulty", workoutDifficulty);
                                    intent.putExtra("workoutCalories", workoutCalories);
                                    intent.putExtra("workoutRating", workoutRating);
                                    intent.putExtra("workoutTargetArea", workoutTargetArea);
                                    intent.putExtra("workoutImageURL", workoutImageURL);
                                    startActivity(intent);
                                }
                            });

                            // The upper Layout is generated
                            lowerLayout.addView(cardView);
                        }
                    }
                });

    }

}