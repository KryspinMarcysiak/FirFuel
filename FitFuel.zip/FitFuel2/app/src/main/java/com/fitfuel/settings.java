package com.fitfuel;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class settings extends AppCompatActivity {

    SharedPreferences prefs = null;
    String userId;
    TextView name, emailTextView, profileWeight, profileHeight, profileGender;
    CardView changePassowrdButton, logOutCardView, profileWeightCard, profileHeightCard, profileGenderCard, uploadImageView;
    ImageView profileImage;
    FirebaseAuth auth;
    FirebaseFirestore fstore;
    private static final int PICK_IMAGE_REQUEST = 1;
    private Uri imageUri;
    private StorageReference storageReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        prefs = getSharedPreferences("com.mycompany.myAppName", MODE_PRIVATE);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.account_activity);

        // Initialize Firebase Storage reference
        storageReference = FirebaseStorage.getInstance().getReference("profile_images");

        // Assign values to variables
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        name = findViewById(R.id.good_message);
        profileImage = findViewById(R.id.profile_icon);
        emailTextView = findViewById(R.id.email_editable);
        changePassowrdButton = findViewById(R.id.change_password);
        profileWeightCard = findViewById(R.id.weight);
        profileWeight = findViewById(R.id.editable_weight);
        profileHeightCard = findViewById(R.id.height);
        profileHeight = findViewById(R.id.editable_height);
        profileGenderCard = findViewById(R.id.gender);
        profileGender = findViewById(R.id.editable_gender);
        logOutCardView = findViewById(R.id.log_out);
        uploadImageView = findViewById(R.id.profile_image_upload);

        // Initialize Firebase
        fstore = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        userId = auth.getCurrentUser().getUid();

        // Set active fragment
        bottomNavigationView.setSelectedItemId(R.id.settings);

        // Fetch user email
        if (user != null) {
            String userEmail = user.getEmail();
            emailTextView.setText(userEmail);
        }

        // Reference to user document
        DocumentReference documentReference = fstore.collection("users").document(userId);

        // Add snapshot listener to fetch user data
        documentReference.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Log.e("account", "Error getting document: " + error);
                    return;
                }
                if (documentSnapshot != null && documentSnapshot.exists()) {
                    String userName = documentSnapshot.getString("user_name");
                    String profileImageURL = documentSnapshot.getString("profile_image");
                    Double userWeight = documentSnapshot.getDouble("user_weight");
                    Double userHeight = documentSnapshot.getDouble("user_height");
                    String userGender = documentSnapshot.getString("user_gender");

                    if (userName != null) {
                        name.setText(userName);
                    }
                    if (userWeight != null) {
                        profileWeight.setText(String.valueOf(userWeight + "kg"));
                    } else {
                        profileWeight.setText("");
                    }
                    if (userHeight != null) {
                        profileHeight.setText(String.valueOf(userHeight + "cm"));
                    } else {
                        profileHeight.setText("");
                    }
                    if (userGender != null) {
                        profileGender.setText(userGender);
                    } else {
                        profileGender.setText("");
                    }
                    if (profileImageURL != null && !profileImageURL.isEmpty()) {
                        Glide.with(settings.this)
                                .load(profileImageURL)
                                .into(profileImage);
                    }
                } else {
                    Log.d("account", "No such document");
                }
            }
        });

        // Bottom navigation item click listener
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            // Function to make the bottom navigation bar intractable
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                // Set conditions to each navigation item from the "bottom_menu" layout
                //If an item is clicked, it will slide out into the next page
                if (item.getItemId() == R.id.home) {
                    startActivity(new Intent(settings.this, MainActivity.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else if (item.getItemId() == R.id.workout) {
                    startActivity(new Intent(settings.this, workout.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else if (item.getItemId() == R.id.meal) {
                    startActivity(new Intent(settings.this, meal.class));
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);
                } else if (item.getItemId() == R.id.settings) {
                    // Current
                }
                return false;
            }
        });

        changePassowrdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText resetMail = new EditText(v.getContext());
                AlertDialog.Builder passwordResetDialog = new AlertDialog.Builder(v.getContext());
                passwordResetDialog.setTitle("Reset Password?");
                passwordResetDialog.setMessage("Enter your email address to receive a reset link.");
                passwordResetDialog.setView(resetMail);

                passwordResetDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String mail = resetMail.getText().toString();
                        auth.sendPasswordResetEmail(mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(settings.this, "Reset link sent to email!", Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(settings.this, "Error! Reset Link Not Sent!" + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });

                passwordResetDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Decline and close
                    }
                });

                passwordResetDialog.create().show();
            }
        });

        logOutCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(settings.this, landing_page_logon.class);
                startActivity(intent);
                finish();
            }
        });

        profileWeightCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(settings.this);
                builder.setTitle("Update Weight (kg)");

                final EditText input = new EditText(settings.this);
                input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                builder.setView(input);

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String newWeightStr = input.getText().toString();
                        if (!newWeightStr.isEmpty()) {
                            try {
                                Double newWeight = Double.parseDouble(newWeightStr);
                                documentReference.update("user_weight", newWeight)
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                profileWeight.setText(String.valueOf(newWeight + "kg"));
                                                Toast.makeText(settings.this, "Weight updated successfully", Toast.LENGTH_SHORT).show();
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Toast.makeText(settings.this, "Failed to update weight", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                            } catch (NumberFormatException e) {
                                Toast.makeText(settings.this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(settings.this, "Weight cannot be empty", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });

        profileHeightCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(settings.this);
                builder.setTitle("Update Height (cm)");

                final EditText input = new EditText(settings.this);
                input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                builder.setView(input);

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String newHeightStr = input.getText().toString();
                        if (!newHeightStr.isEmpty()) {
                            try {
                                Double newHeight = Double.parseDouble(newHeightStr);
                                documentReference.update("user_height", newHeight)
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                profileHeight.setText(String.valueOf(newHeight + "cm"));
                                                Toast.makeText(settings.this, "Height updated successfully", Toast.LENGTH_SHORT).show();
                                            }
                                        })
                                        .addOnFailureListener(new OnFailureListener() {
                                            @Override
                                            public void onFailure(@NonNull Exception e) {
                                                Toast.makeText(settings.this, "Failed to update height", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                            } catch (NumberFormatException e) {
                                Toast.makeText(settings.this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(settings.this, "Height cannot be empty", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });

        profileGenderCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(settings.this);
                builder.setTitle("Update Gender (Male, Female or Other)");

                final EditText input = new EditText(settings.this);
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                builder.setView(input);

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String newGenderStr = input.getText().toString();
                        if (!newGenderStr.isEmpty()) {
                            String newGender = newGenderStr.trim();
                            documentReference.update("user_gender", newGender)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void aVoid) {
                                            profileGender.setText(newGender);
                                            Toast.makeText(settings.this, "Gender updated successfully", Toast.LENGTH_SHORT).show();
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            Toast.makeText(settings.this, "Failed to update gender", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        } else {
                            Toast.makeText(settings.this, "Gender cannot be empty", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                builder.show();
            }
        });

        uploadImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });

    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            uploadImageToFirebase();
        }
    }

    private void uploadImageToFirebase() {
        if (imageUri != null) {
            StorageReference fileReference = storageReference.child(userId + ".jpg");
            fileReference.putFile(imageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            fileReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    String imageUrl = uri.toString();
                                    DocumentReference documentReference = fstore.collection("users").document(userId);
                                    documentReference.update("profile_image", imageUrl)
                                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    Glide.with(settings.this)
                                                            .load(imageUrl)
                                                            .into(profileImage);
                                                    Toast.makeText(settings.this, "Profile image updated successfully", Toast.LENGTH_SHORT).show();
                                                }
                                            })
                                            .addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    Toast.makeText(settings.this, "Failed to update profile image", Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                }
                            });
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(settings.this, "Failed to upload image", Toast.LENGTH_SHORT).show();
                        }
                    });
        } else {
            Toast.makeText(this, "No file selected", Toast.LENGTH_SHORT).show();
        }
    }
}
